@extends('layouts.app')

@section('title', 'Edit Janji - KlinikWeb')
@section('page_title', 'Edit Janji Layanan')

@section('content')
    <section class="panel">
        <form method="POST" action="{{ route('appointments.update', $appointment) }}">
            @method('PUT')
            @include('user.appointments._form')
        </form>
    </section>
@endsection
