@extends('layouts.app')

@section('title', 'Janji Layanan - KlinikWeb')
@section('page_title', 'Janji Layanan Saya')

@section('top_action')
    @if(auth()->user()->is_verified)
        <a class="btn" href="{{ route('appointments.create') }}">Buat Janji</a>
    @endif
@endsection

@section('content')
    @unless(auth()->user()->is_verified)
        <div class="alert error">Akun Anda belum diverifikasi admin, jadi belum bisa membuat janji layanan.</div>
    @endunless

    <section class="panel">
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Tanggal</th>
                        <th>Layanan</th>
                        <th>Dokter</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($appointments as $appointment)
                        <tr>
                            <td><strong>{{ $appointment->code }}</strong></td>
                            <td>{{ $appointment->appointment_date->format('d M Y H:i') }}</td>
                            <td>{{ $appointment->service->name }}</td>
                            <td>{{ $appointment->doctor->name }}</td>
                            <td>Rp {{ number_format($appointment->total_fee, 0, ',', '.') }}</td>
                            <td><span class="badge {{ $appointment->status }}">{{ $appointment->statusLabel() }}</span></td>
                            <td>
                                <div class="actions">
                                    <a class="btn secondary" href="{{ route('appointments.show', $appointment) }}">Detail</a>
                                    @if(in_array($appointment->status, ['pending', 'rejected'], true))
                                        <a class="btn secondary" href="{{ route('appointments.edit', $appointment) }}">Edit</a>
                                    @endif
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="7">Belum ada janji layanan.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="pagination">{{ $appointments->links() }}</div>
    </section>
@endsection
