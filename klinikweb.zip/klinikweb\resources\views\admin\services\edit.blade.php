@extends('layouts.app')

@section('title', 'Edit Layanan - KlinikWeb')
@section('page_title', 'Edit Layanan')

@section('content')
    <section class="panel">
        <form method="POST" action="{{ route('admin.services.update', $service) }}">
            @method('PUT')
            @include('admin.services._form')
        </form>
    </section>
@endsection
