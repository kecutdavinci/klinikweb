@csrf

<div class="form-grid">
    <div class="field">
        <label for="doctor_id">Dokter</label>
        <select id="doctor_id" name="doctor_id" required>
            <option value="">Pilih dokter</option>
            @foreach($doctors as $doctor)
                <option value="{{ $doctor->id }}" @selected((int) old('doctor_id', $appointment->doctor_id) === $doctor->id)>
                    {{ $doctor->name }} - {{ $doctor->specialization }} ({{ $doctor->schedule }})
                </option>
            @endforeach
        </select>
    </div>

    <div class="field">
        <label for="service_id">Layanan</label>
        <select id="service_id" name="service_id" required>
            <option value="">Pilih layanan</option>
            @foreach($services as $service)
                <option value="{{ $service->id }}" @selected((int) old('service_id', $appointment->service_id) === $service->id)>
                    {{ $service->name }} - Rp {{ number_format($service->price, 0, ',', '.') }}
                </option>
            @endforeach
        </select>
    </div>

    <div class="field">
        <label for="appointment_date">Tanggal dan Jam</label>
        <input id="appointment_date" type="datetime-local" name="appointment_date" value="{{ old('appointment_date', $appointment->appointment_date?->format('Y-m-d\TH:i')) }}" required>
    </div>

    <div class="field">
        <label for="complaint">Keluhan</label>
        <textarea id="complaint" name="complaint" required>{{ old('complaint', $appointment->complaint) }}</textarea>
    </div>

    <div class="actions">
        <button class="btn" type="submit">Simpan</button>
        <a class="btn secondary" href="{{ route('appointments.index') }}">Batal</a>
    </div>
</div>
