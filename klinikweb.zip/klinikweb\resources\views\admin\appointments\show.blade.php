@extends('layouts.app')

@section('title', 'Detail Transaksi - KlinikWeb')
@section('page_title', 'Detail Transaksi')

@section('top_action')
    <a class="btn secondary" href="{{ route('admin.appointments.index') }}">Kembali</a>
@endsection

@section('content')
    <section class="panel">
        <div class="panel-header">
            <h2 class="panel-title">{{ $appointment->code }}</h2>
            <span class="badge {{ $appointment->status }}">{{ $appointment->statusLabel() }}</span>
        </div>

        <dl class="detail-list">
            <dt>User</dt>
            <dd>{{ $appointment->user->name }} - {{ $appointment->user->email }}</dd>
            <dt>Dokter</dt>
            <dd>{{ $appointment->doctor->name }} ({{ $appointment->doctor->specialization }})</dd>
            <dt>Layanan</dt>
            <dd>{{ $appointment->service->name }}</dd>
            <dt>Tanggal Janji</dt>
            <dd>{{ $appointment->appointment_date->format('d M Y H:i') }}</dd>
            <dt>Total Biaya</dt>
            <dd>Rp {{ number_format($appointment->total_fee, 0, ',', '.') }}</dd>
            <dt>Keluhan</dt>
            <dd>{{ $appointment->complaint }}</dd>
            <dt>Catatan Admin</dt>
            <dd>{{ $appointment->admin_note ?: '-' }}</dd>
            <dt>Diverifikasi Oleh</dt>
            <dd>{{ $appointment->verifier?->name ?: '-' }}</dd>
            <dt>Waktu Verifikasi</dt>
            <dd>{{ $appointment->verified_at?->format('d M Y H:i') ?: '-' }}</dd>
        </dl>
    </section>

    @if(in_array($appointment->status, ['pending', 'rejected'], true))
        <section class="panel">
            <h2 class="panel-title">Verifikasi Transaksi</h2>
            <form class="form-grid" method="POST" action="{{ route('admin.appointments.verify', $appointment) }}">
                @csrf
                @method('PATCH')
                <div class="field">
                    <label for="admin_note_verify">Catatan Admin</label>
                    <textarea id="admin_note_verify" name="admin_note" placeholder="Opsional">{{ old('admin_note') }}</textarea>
                </div>
                <button class="btn success" type="submit">Verifikasi</button>
            </form>
        </section>
    @endif

    @if(in_array($appointment->status, ['pending', 'verified'], true))
        <section class="panel">
            <h2 class="panel-title">Tolak Transaksi</h2>
            <form class="form-grid" method="POST" action="{{ route('admin.appointments.reject', $appointment) }}">
                @csrf
                @method('PATCH')
                <div class="field">
                    <label for="admin_note_reject">Alasan Penolakan</label>
                    <textarea id="admin_note_reject" name="admin_note" required>{{ old('admin_note') }}</textarea>
                </div>
                <button class="btn danger" type="submit">Tolak</button>
            </form>
        </section>
    @endif

    @if($appointment->status === 'verified')
        <section class="panel">
            <h2 class="panel-title">Selesaikan Transaksi</h2>
            <form class="form-grid" method="POST" action="{{ route('admin.appointments.complete', $appointment) }}">
                @csrf
                @method('PATCH')
                <div class="field">
                    <label for="admin_note_complete">Catatan Penyelesaian</label>
                    <textarea id="admin_note_complete" name="admin_note">{{ old('admin_note', $appointment->admin_note) }}</textarea>
                </div>
                <button class="btn" type="submit">Selesai</button>
            </form>
        </section>
    @endif
@endsection
