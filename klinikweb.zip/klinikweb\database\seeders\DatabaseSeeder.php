<?php

namespace Database\Seeders;

use App\Models\Appointment;
use App\Models\Doctor;
use App\Models\Service;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $admin = User::updateOrCreate(
            ['email' => 'admin@klinikweb.test'],
            [
                'name' => 'Admin Klinik',
                'password' => Hash::make('password'),
                'role' => 'admin',
                'is_verified' => true,
                'email_verified_at' => now(),
            ]
        );

        $user = User::updateOrCreate(
            ['email' => 'user@klinikweb.test'],
            [
                'name' => 'Budi Santoso',
                'password' => Hash::make('password'),
                'role' => 'user',
                'is_verified' => true,
                'email_verified_at' => now(),
            ]
        );

        User::updateOrCreate(
            ['email' => 'baru@klinikweb.test'],
            [
                'name' => 'Siti Menunggu',
                'password' => Hash::make('password'),
                'role' => 'user',
                'is_verified' => false,
                'email_verified_at' => null,
            ]
        );

        $doctorA = Doctor::updateOrCreate(
            ['name' => 'dr. Andini Putri'],
            [
                'specialization' => 'Dokter Umum',
                'phone' => '081234567890',
                'schedule' => 'Senin-Jumat, 08.00-14.00',
                'is_active' => true,
            ]
        );

        $doctorB = Doctor::updateOrCreate(
            ['name' => 'dr. Raka Pratama'],
            [
                'specialization' => 'Dokter Gigi',
                'phone' => '081298765432',
                'schedule' => 'Selasa-Sabtu, 10.00-16.00',
                'is_active' => true,
            ]
        );

        $serviceA = Service::updateOrCreate(
            ['name' => 'Konsultasi Umum'],
            [
                'description' => 'Pemeriksaan awal dan konsultasi kesehatan.',
                'price' => 75000,
                'is_active' => true,
            ]
        );

        $serviceB = Service::updateOrCreate(
            ['name' => 'Perawatan Gigi'],
            [
                'description' => 'Pemeriksaan dan tindakan perawatan gigi dasar.',
                'price' => 150000,
                'is_active' => true,
            ]
        );

        Appointment::updateOrCreate(
            ['code' => 'TRX-DEMO-001'],
            [
                'user_id' => $user->id,
                'doctor_id' => $doctorA->id,
                'service_id' => $serviceA->id,
                'appointment_date' => now()->addDays(2)->setTime(9, 0),
                'complaint' => 'Demam ringan dan pusing sejak kemarin.',
                'status' => 'pending',
                'total_fee' => $serviceA->price,
                'admin_note' => null,
                'verified_by' => null,
                'verified_at' => null,
            ]
        );

        Appointment::updateOrCreate(
            ['code' => 'TRX-DEMO-002'],
            [
                'user_id' => $user->id,
                'doctor_id' => $doctorB->id,
                'service_id' => $serviceB->id,
                'appointment_date' => now()->addDays(4)->setTime(11, 30),
                'complaint' => 'Kontrol gigi dan pembersihan karang gigi.',
                'status' => 'verified',
                'total_fee' => $serviceB->price,
                'admin_note' => 'Datang 15 menit sebelum jadwal.',
                'verified_by' => $admin->id,
                'verified_at' => now(),
            ]
        );
    }
}
