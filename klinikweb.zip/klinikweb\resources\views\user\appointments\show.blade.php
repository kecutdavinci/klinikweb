@extends('layouts.app')

@section('title', 'Detail Janji - KlinikWeb')
@section('page_title', 'Detail Janji Layanan')

@section('top_action')
    <a class="btn secondary" href="{{ route('appointments.index') }}">Kembali</a>
@endsection

@section('content')
    <section class="panel">
        <div class="panel-header">
            <h2 class="panel-title">{{ $appointment->code }}</h2>
            <span class="badge {{ $appointment->status }}">{{ $appointment->statusLabel() }}</span>
        </div>

        <dl class="detail-list">
            <dt>Dokter</dt>
            <dd>{{ $appointment->doctor->name }} ({{ $appointment->doctor->specialization }})</dd>
            <dt>Jadwal Dokter</dt>
            <dd>{{ $appointment->doctor->schedule }}</dd>
            <dt>Layanan</dt>
            <dd>{{ $appointment->service->name }}</dd>
            <dt>Tanggal Janji</dt>
            <dd>{{ $appointment->appointment_date->format('d M Y H:i') }}</dd>
            <dt>Total Biaya</dt>
            <dd>Rp {{ number_format($appointment->total_fee, 0, ',', '.') }}</dd>
            <dt>Keluhan</dt>
            <dd>{{ $appointment->complaint }}</dd>
            <dt>Catatan Admin</dt>
            <dd>{{ $appointment->admin_note ?: '-' }}</dd>
            <dt>Diverifikasi Oleh</dt>
            <dd>{{ $appointment->verifier?->name ?: '-' }}</dd>
        </dl>
    </section>

    <section class="panel">
        <div class="actions">
            @if(in_array($appointment->status, ['pending', 'rejected'], true))
                <a class="btn secondary" href="{{ route('appointments.edit', $appointment) }}">Edit</a>
            @endif

            @if(! in_array($appointment->status, ['completed', 'cancelled'], true))
                <form method="POST" action="{{ route('appointments.cancel', $appointment) }}" onsubmit="return confirm('Batalkan janji layanan ini?')">
                    @csrf
                    @method('PATCH')
                    <button class="btn warning" type="submit">Batalkan</button>
                </form>
            @endif

            @if(in_array($appointment->status, ['pending', 'rejected', 'cancelled'], true))
                <form method="POST" action="{{ route('appointments.destroy', $appointment) }}" onsubmit="return confirm('Hapus transaksi ini?')">
                    @csrf
                    @method('DELETE')
                    <button class="btn danger" type="submit">Hapus</button>
                </form>
            @endif
        </div>
    </section>
@endsection
