@extends('layouts.app')

@section('title', 'Edit Dokter - KlinikWeb')
@section('page_title', 'Edit Dokter')

@section('content')
    <section class="panel">
        <form method="POST" action="{{ route('admin.doctors.update', $doctor) }}">
            @method('PUT')
            @include('admin.doctors._form')
        </form>
    </section>
@endsection
