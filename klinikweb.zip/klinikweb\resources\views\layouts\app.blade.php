<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'KlinikWeb')</title>
    <style>
        :root {
            --bg: #f5f7fb;
            --surface: #ffffff;
            --line: #dbe3ef;
            --text: #1f2937;
            --muted: #667085;
            --primary: #0f766e;
            --primary-dark: #115e59;
            --danger: #b42318;
            --warning: #b54708;
            --success: #067647;
            --info: #175cd3;
            --radius: 8px;
        }

        * { box-sizing: border-box; }
        body {
            margin: 0;
            background: var(--bg);
            color: var(--text);
            font-family: Arial, Helvetica, sans-serif;
            font-size: 15px;
            line-height: 1.5;
        }

        a { color: inherit; text-decoration: none; }
        .app-shell { min-height: 100vh; display: flex; }
        .sidebar {
            width: 252px;
            flex: 0 0 252px;
            background: #111827;
            color: #f9fafb;
            padding: 22px 18px;
            display: flex;
            flex-direction: column;
            gap: 22px;
        }
        .brand { font-weight: 800; font-size: 22px; letter-spacing: 0; }
        .role-pill {
            display: inline-flex;
            align-items: center;
            padding: 4px 9px;
            border-radius: 999px;
            background: #374151;
            color: #d1d5db;
            font-size: 12px;
            margin-top: 6px;
        }
        .nav { display: grid; gap: 7px; }
        .nav a {
            padding: 10px 12px;
            border-radius: var(--radius);
            color: #d1d5db;
        }
        .nav a.active, .nav a:hover { background: #1f2937; color: #ffffff; }
        .sidebar-footer { margin-top: auto; }
        .main { flex: 1; min-width: 0; padding: 24px; }
        .guest-main {
            min-height: 100vh;
            width: 100%;
            display: grid;
            place-items: center;
            padding: 24px;
        }
        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            margin-bottom: 20px;
        }
        .page-title { margin: 0; font-size: 26px; line-height: 1.2; }
        .muted { color: var(--muted); }
        .panel {
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: var(--radius);
            padding: 18px;
            margin-bottom: 18px;
        }
        .panel-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            margin-bottom: 14px;
        }
        .panel-title { margin: 0; font-size: 18px; }
        .grid { display: grid; gap: 14px; }
        .grid-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        .grid-3 { grid-template-columns: repeat(3, minmax(0, 1fr)); }
        .grid-4 { grid-template-columns: repeat(4, minmax(0, 1fr)); }
        .stat {
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: var(--radius);
            padding: 16px;
        }
        .stat strong { display: block; font-size: 28px; line-height: 1.1; }
        .table-wrap { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th, td { text-align: left; padding: 12px 10px; border-bottom: 1px solid var(--line); vertical-align: top; }
        th { font-size: 13px; color: var(--muted); background: #f8fafc; }
        .actions { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            min-height: 38px;
            padding: 8px 12px;
            border-radius: var(--radius);
            border: 1px solid transparent;
            background: var(--primary);
            color: #ffffff;
            cursor: pointer;
            font: inherit;
            font-weight: 700;
            white-space: nowrap;
        }
        .btn:hover { background: var(--primary-dark); }
        .btn.secondary { background: #ffffff; color: var(--text); border-color: var(--line); }
        .btn.secondary:hover { background: #f8fafc; }
        .btn.danger { background: var(--danger); }
        .btn.warning { background: var(--warning); }
        .btn.success { background: var(--success); }
        .btn.link { background: transparent; color: #d1d5db; border-color: #374151; width: 100%; }
        .badge {
            display: inline-flex;
            align-items: center;
            padding: 4px 8px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 700;
        }
        .badge.pending { background: #fff4e5; color: var(--warning); }
        .badge.verified { background: #e0f2fe; color: var(--info); }
        .badge.rejected { background: #fee4e2; color: var(--danger); }
        .badge.completed { background: #dcfae6; color: var(--success); }
        .badge.cancelled { background: #eef2f6; color: #475467; }
        .badge.ok { background: #dcfae6; color: var(--success); }
        .badge.no { background: #fee4e2; color: var(--danger); }
        .form-grid { display: grid; gap: 14px; }
        .field { display: grid; gap: 6px; }
        label { font-weight: 700; }
        input, select, textarea {
            width: 100%;
            min-height: 40px;
            border: 1px solid var(--line);
            border-radius: var(--radius);
            padding: 9px 11px;
            font: inherit;
            background: #ffffff;
        }
        textarea { min-height: 110px; resize: vertical; }
        .checkbox { display: flex; align-items: center; gap: 8px; }
        .checkbox input { width: 18px; min-height: 18px; }
        .error-text { color: var(--danger); font-size: 13px; }
        .alert {
            border-radius: var(--radius);
            padding: 12px 14px;
            margin-bottom: 16px;
            border: 1px solid var(--line);
            background: #ffffff;
        }
        .alert.success { border-color: #abefc6; color: var(--success); background: #f6fef9; }
        .alert.error { border-color: #fecdca; color: var(--danger); background: #fffbfa; }
        .auth-card {
            width: min(440px, 100%);
            background: #ffffff;
            border: 1px solid var(--line);
            border-radius: var(--radius);
            padding: 24px;
        }
        .auth-title { margin: 0 0 6px; font-size: 28px; }
        .auth-switch { margin-top: 16px; color: var(--muted); }
        .auth-switch a { color: var(--primary); font-weight: 700; }
        .pagination { margin-top: 14px; }
        .detail-list { display: grid; grid-template-columns: 180px 1fr; gap: 10px 14px; }
        .detail-list dt { font-weight: 700; color: var(--muted); }
        .detail-list dd { margin: 0; }

        @media (max-width: 900px) {
            .app-shell { display: block; }
            .sidebar { width: 100%; flex: none; }
            .grid-2, .grid-3, .grid-4 { grid-template-columns: 1fr; }
            .topbar, .panel-header { align-items: flex-start; flex-direction: column; }
            .main { padding: 16px; }
            .detail-list { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
@auth
    <div class="app-shell">
        <aside class="sidebar">
            <div>
                <div class="brand">KlinikWeb</div>
                <span class="role-pill">{{ auth()->user()->role === 'admin' ? 'Admin' : 'User' }}</span>
            </div>

            <nav class="nav">
                @if(auth()->user()->role === 'admin')
                    <a class="{{ request()->routeIs('admin.dashboard') ? 'active' : '' }}" href="{{ route('admin.dashboard') }}">Dashboard</a>
                    <a class="{{ request()->routeIs('admin.users.*') ? 'active' : '' }}" href="{{ route('admin.users.index') }}">Verifikasi User</a>
                    <a class="{{ request()->routeIs('admin.doctors.*') ? 'active' : '' }}" href="{{ route('admin.doctors.index') }}">Data Dokter</a>
                    <a class="{{ request()->routeIs('admin.services.*') ? 'active' : '' }}" href="{{ route('admin.services.index') }}">Data Layanan</a>
                    <a class="{{ request()->routeIs('admin.appointments.*') ? 'active' : '' }}" href="{{ route('admin.appointments.index') }}">Transaksi</a>
                @else
                    <a class="{{ request()->routeIs('user.dashboard') ? 'active' : '' }}" href="{{ route('user.dashboard') }}">Dashboard</a>
                    <a class="{{ request()->routeIs('appointments.*') ? 'active' : '' }}" href="{{ route('appointments.index') }}">Janji Layanan</a>
                @endif
            </nav>

            <div class="sidebar-footer">
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button class="btn link" type="submit">Logout</button>
                </form>
            </div>
        </aside>

        <main class="main">
            <div class="topbar">
                <div>
                    <h1 class="page-title">@yield('page_title', 'KlinikWeb')</h1>
                    <div class="muted">{{ auth()->user()->name }} - {{ auth()->user()->email }}</div>
                </div>
                @yield('top_action')
            </div>

            @include('layouts.flash')
            @yield('content')
        </main>
    </div>
@else
    <main class="guest-main">
        @include('layouts.flash')
        @yield('content')
    </main>
@endauth
</body>
</html>
