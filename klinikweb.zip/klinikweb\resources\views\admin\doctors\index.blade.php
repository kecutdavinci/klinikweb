@extends('layouts.app')

@section('title', 'Data Dokter - KlinikWeb')
@section('page_title', 'Data Dokter')

@section('top_action')
    <a class="btn" href="{{ route('admin.doctors.create') }}">Tambah Dokter</a>
@endsection

@section('content')
    <section class="panel">
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Spesialis</th>
                        <th>Telepon</th>
                        <th>Jadwal</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($doctors as $doctor)
                        <tr>
                            <td>{{ $doctor->name }}</td>
                            <td>{{ $doctor->specialization }}</td>
                            <td>{{ $doctor->phone ?: '-' }}</td>
                            <td>{{ $doctor->schedule }}</td>
                            <td>
                                <span class="badge {{ $doctor->is_active ? 'ok' : 'no' }}">
                                    {{ $doctor->is_active ? 'Aktif' : 'Nonaktif' }}
                                </span>
                            </td>
                            <td>
                                <div class="actions">
                                    <a class="btn secondary" href="{{ route('admin.doctors.edit', $doctor) }}">Edit</a>
                                    <form method="POST" action="{{ route('admin.doctors.destroy', $doctor) }}" onsubmit="return confirm('Hapus dokter ini?')">
                                        @csrf
                                        @method('DELETE')
                                        <button class="btn danger" type="submit">Hapus</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="6">Belum ada data dokter.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="pagination">{{ $doctors->links() }}</div>
    </section>
@endsection
