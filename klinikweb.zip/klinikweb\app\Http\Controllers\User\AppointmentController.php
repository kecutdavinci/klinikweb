<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Appointment;
use App\Models\Doctor;
use App\Models\Service;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\View\View;

class AppointmentController extends Controller
{
    public function index(): View
    {
        return view('user.appointments.index', [
            'appointments' => Auth::user()->appointments()
                ->with(['doctor', 'service', 'verifier'])
                ->latest()
                ->paginate(10),
        ]);
    }

    public function create(): View|RedirectResponse
    {
        if (! Auth::user()->is_verified) {
            return redirect()->route('user.dashboard')->with('error', 'Akun Anda belum diverifikasi admin.');
        }

        return view('user.appointments.create', [
            'appointment' => new Appointment(),
            'doctors' => Doctor::where('is_active', true)->orderBy('name')->get(),
            'services' => Service::where('is_active', true)->orderBy('name')->get(),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        if (! Auth::user()->is_verified) {
            return redirect()->route('user.dashboard')->with('error', 'Akun Anda belum diverifikasi admin.');
        }

        $data = $this->validatedData($request);
        $service = Service::findOrFail($data['service_id']);

        Appointment::create([
            'code' => $this->generateCode(),
            'user_id' => Auth::id(),
            'doctor_id' => $data['doctor_id'],
            'service_id' => $data['service_id'],
            'appointment_date' => $data['appointment_date'],
            'complaint' => $data['complaint'],
            'status' => 'pending',
            'total_fee' => $service->price,
        ]);

        return redirect()->route('appointments.index')->with('status', 'Janji layanan berhasil dibuat dan menunggu verifikasi admin.');
    }

    public function show(Appointment $appointment): View
    {
        $this->ensureOwner($appointment);

        return view('user.appointments.show', [
            'appointment' => $appointment->load(['doctor', 'service', 'verifier']),
        ]);
    }

    public function edit(Appointment $appointment): View|RedirectResponse
    {
        $this->ensureOwner($appointment);

        if (! in_array($appointment->status, ['pending', 'rejected'], true)) {
            return back()->with('error', 'Transaksi hanya bisa diedit saat menunggu verifikasi atau ditolak.');
        }

        return view('user.appointments.edit', [
            'appointment' => $appointment,
            'doctors' => Doctor::where('is_active', true)->orderBy('name')->get(),
            'services' => Service::where('is_active', true)->orderBy('name')->get(),
        ]);
    }

    public function update(Request $request, Appointment $appointment): RedirectResponse
    {
        $this->ensureOwner($appointment);

        if (! in_array($appointment->status, ['pending', 'rejected'], true)) {
            return back()->with('error', 'Transaksi hanya bisa diedit saat menunggu verifikasi atau ditolak.');
        }

        $data = $this->validatedData($request);
        $service = Service::findOrFail($data['service_id']);

        $appointment->update([
            'doctor_id' => $data['doctor_id'],
            'service_id' => $data['service_id'],
            'appointment_date' => $data['appointment_date'],
            'complaint' => $data['complaint'],
            'status' => 'pending',
            'total_fee' => $service->price,
            'admin_note' => null,
            'verified_by' => null,
            'verified_at' => null,
        ]);

        return redirect()->route('appointments.show', $appointment)->with('status', 'Transaksi diperbarui dan kembali menunggu verifikasi admin.');
    }

    public function destroy(Appointment $appointment): RedirectResponse
    {
        $this->ensureOwner($appointment);

        if (! in_array($appointment->status, ['pending', 'rejected', 'cancelled'], true)) {
            return back()->with('error', 'Transaksi ini tidak bisa dihapus karena sudah diproses admin.');
        }

        $appointment->delete();

        return redirect()->route('appointments.index')->with('status', 'Transaksi berhasil dihapus.');
    }

    public function cancel(Appointment $appointment): RedirectResponse
    {
        $this->ensureOwner($appointment);

        if (in_array($appointment->status, ['completed', 'cancelled'], true)) {
            return back()->with('error', 'Transaksi ini tidak bisa dibatalkan.');
        }

        $appointment->update([
            'status' => 'cancelled',
            'admin_note' => 'Dibatalkan oleh user.',
        ]);

        return redirect()->route('appointments.show', $appointment)->with('status', 'Transaksi berhasil dibatalkan.');
    }

    private function validatedData(Request $request): array
    {
        return $request->validate([
            'doctor_id' => [
                'required',
                Rule::exists('doctors', 'id')->where('is_active', true),
            ],
            'service_id' => [
                'required',
                Rule::exists('services', 'id')->where('is_active', true),
            ],
            'appointment_date' => ['required', 'date', 'after_or_equal:today'],
            'complaint' => ['required', 'string', 'max:1000'],
        ]);
    }

    private function ensureOwner(Appointment $appointment): void
    {
        abort_unless($appointment->user_id === Auth::id(), 403);
    }

    private function generateCode(): string
    {
        do {
            $code = 'TRX-'.now()->format('Ymd').'-'.Str::upper(Str::random(5));
        } while (Appointment::where('code', $code)->exists());

        return $code;
    }
}
