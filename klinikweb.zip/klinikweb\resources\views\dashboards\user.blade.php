@extends('layouts.app')

@section('title', 'Dashboard User - KlinikWeb')
@section('page_title', 'Dashboard User')

@section('top_action')
    @if(auth()->user()->is_verified)
        <a class="btn" href="{{ route('appointments.create') }}">Buat Janji</a>
    @endif
@endsection

@section('content')
    @unless(auth()->user()->is_verified)
        <div class="alert error">
            Akun Anda belum diverifikasi admin. Setelah diverifikasi, menu pembuatan janji layanan akan aktif.
        </div>
    @endunless

    <div class="grid grid-3">
        <div class="stat">
            <span class="muted">Total Janji</span>
            <strong>{{ $totalAppointments }}</strong>
        </div>
        <div class="stat">
            <span class="muted">Menunggu Verifikasi</span>
            <strong>{{ $pendingAppointments }}</strong>
        </div>
        <div class="stat">
            <span class="muted">Terverifikasi</span>
            <strong>{{ $verifiedAppointments }}</strong>
        </div>
    </div>

    <section class="panel" style="margin-top:18px;">
        <div class="panel-header">
            <h2 class="panel-title">Janji Layanan Terbaru</h2>
            <a class="btn secondary" href="{{ route('appointments.index') }}">Lihat Semua</a>
        </div>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Tanggal</th>
                        <th>Layanan</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($appointments as $appointment)
                        <tr>
                            <td><a href="{{ route('appointments.show', $appointment) }}"><strong>{{ $appointment->code }}</strong></a></td>
                            <td>{{ $appointment->appointment_date->format('d M Y H:i') }}</td>
                            <td>{{ $appointment->service->name }}</td>
                            <td><span class="badge {{ $appointment->status }}">{{ $appointment->statusLabel() }}</span></td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="4">Belum ada janji layanan.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </section>

    <div class="grid grid-2">
        <section class="panel">
            <h2 class="panel-title">Layanan Aktif</h2>
            <div class="table-wrap">
                <table>
                    <tbody>
                        @forelse($services as $service)
                            <tr>
                                <td>{{ $service->name }}</td>
                                <td>Rp {{ number_format($service->price, 0, ',', '.') }}</td>
                            </tr>
                        @empty
                            <tr><td>Belum ada layanan aktif.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </section>

        <section class="panel">
            <h2 class="panel-title">Dokter Aktif</h2>
            <div class="table-wrap">
                <table>
                    <tbody>
                        @forelse($doctors as $doctor)
                            <tr>
                                <td>{{ $doctor->name }}</td>
                                <td>{{ $doctor->specialization }}</td>
                            </tr>
                        @empty
                            <tr><td>Belum ada dokter aktif.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </section>
    </div>
@endsection
