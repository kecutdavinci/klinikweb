@extends('layouts.app')

@section('title', 'Dashboard Admin - KlinikWeb')
@section('page_title', 'Dashboard Admin')

@section('content')
    <div class="grid grid-4">
        <div class="stat">
            <span class="muted">User Terdaftar</span>
            <strong>{{ $totalUsers }}</strong>
        </div>
        <div class="stat">
            <span class="muted">User Belum Verifikasi</span>
            <strong>{{ $pendingUsers }}</strong>
        </div>
        <div class="stat">
            <span class="muted">Dokter</span>
            <strong>{{ $totalDoctors }}</strong>
        </div>
        <div class="stat">
            <span class="muted">Layanan</span>
            <strong>{{ $totalServices }}</strong>
        </div>
    </div>

    <div class="grid grid-2" style="margin-top:14px;">
        <div class="stat">
            <span class="muted">Transaksi Menunggu</span>
            <strong>{{ $pendingAppointments }}</strong>
        </div>
        <div class="stat">
            <span class="muted">Transaksi Selesai</span>
            <strong>{{ $completedAppointments }}</strong>
        </div>
    </div>

    <section class="panel" style="margin-top:18px;">
        <div class="panel-header">
            <h2 class="panel-title">Transaksi Terbaru</h2>
            <a class="btn secondary" href="{{ route('admin.appointments.index') }}">Lihat Semua</a>
        </div>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>User</th>
                        <th>Layanan</th>
                        <th>Dokter</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($latestAppointments as $appointment)
                        <tr>
                            <td><a href="{{ route('admin.appointments.show', $appointment) }}"><strong>{{ $appointment->code }}</strong></a></td>
                            <td>{{ $appointment->user->name }}</td>
                            <td>{{ $appointment->service->name }}</td>
                            <td>{{ $appointment->doctor->name }}</td>
                            <td><span class="badge {{ $appointment->status }}">{{ $appointment->statusLabel() }}</span></td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5">Belum ada transaksi.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </section>
@endsection
