@extends('layouts.app')

@section('title', 'Daftar - KlinikWeb')

@section('content')
    <section class="auth-card">
        <h1 class="auth-title">Daftar User</h1>
        <p class="muted">Akun baru perlu diverifikasi admin.</p>

        <form class="form-grid" method="POST" action="{{ route('register.store') }}">
            @csrf
            <div class="field">
                <label for="name">Nama</label>
                <input id="name" type="text" name="name" value="{{ old('name') }}" required autofocus>
            </div>

            <div class="field">
                <label for="email">Email</label>
                <input id="email" type="email" name="email" value="{{ old('email') }}" required>
            </div>

            <div class="field">
                <label for="password">Password</label>
                <input id="password" type="password" name="password" required>
            </div>

            <div class="field">
                <label for="password_confirmation">Konfirmasi Password</label>
                <input id="password_confirmation" type="password" name="password_confirmation" required>
            </div>

            <button class="btn" type="submit">Daftar</button>
        </form>

        <p class="auth-switch">
            Sudah punya akun?
            <a href="{{ route('login') }}">Login</a>
        </p>
    </section>
@endsection
