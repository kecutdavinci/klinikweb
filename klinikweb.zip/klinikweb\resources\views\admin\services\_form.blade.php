@csrf

<div class="form-grid">
    <div class="field">
        <label for="name">Nama Layanan</label>
        <input id="name" name="name" value="{{ old('name', $service->name) }}" required>
    </div>

    <div class="field">
        <label for="price">Harga</label>
        <input id="price" type="number" min="0" name="price" value="{{ old('price', $service->price) }}" required>
    </div>

    <div class="field">
        <label for="description">Deskripsi</label>
        <textarea id="description" name="description">{{ old('description', $service->description) }}</textarea>
    </div>

    <label class="checkbox">
        <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $service->exists ? $service->is_active : true))>
        Aktif
    </label>

    <div class="actions">
        <button class="btn" type="submit">Simpan</button>
        <a class="btn secondary" href="{{ route('admin.services.index') }}">Batal</a>
    </div>
</div>
