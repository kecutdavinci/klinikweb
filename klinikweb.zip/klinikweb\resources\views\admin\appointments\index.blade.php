@extends('layouts.app')

@section('title', 'Transaksi Admin - KlinikWeb')
@section('page_title', 'Transaksi Janji Layanan')

@section('content')
    <section class="panel">
        <form class="actions" method="GET" action="{{ route('admin.appointments.index') }}" style="margin-bottom:14px;">
            <select name="status" style="max-width:260px;">
                <option value="">Semua status</option>
                @foreach($statuses as $value => $label)
                    <option value="{{ $value }}" @selected($status === $value)>{{ $label }}</option>
                @endforeach
            </select>
            <button class="btn secondary" type="submit">Filter</button>
            <a class="btn secondary" href="{{ route('admin.appointments.index') }}">Reset</a>
        </form>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>User</th>
                        <th>Tanggal</th>
                        <th>Layanan</th>
                        <th>Dokter</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($appointments as $appointment)
                        <tr>
                            <td><strong>{{ $appointment->code }}</strong></td>
                            <td>{{ $appointment->user->name }}</td>
                            <td>{{ $appointment->appointment_date->format('d M Y H:i') }}</td>
                            <td>{{ $appointment->service->name }}</td>
                            <td>{{ $appointment->doctor->name }}</td>
                            <td>Rp {{ number_format($appointment->total_fee, 0, ',', '.') }}</td>
                            <td><span class="badge {{ $appointment->status }}">{{ $appointment->statusLabel() }}</span></td>
                            <td><a class="btn secondary" href="{{ route('admin.appointments.show', $appointment) }}">Detail</a></td>
                        </tr>
                    @empty
                        <tr><td colspan="8">Belum ada transaksi.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="pagination">{{ $appointments->links() }}</div>
    </section>
@endsection
