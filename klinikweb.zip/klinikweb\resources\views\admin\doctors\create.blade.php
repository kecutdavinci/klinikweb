@extends('layouts.app')

@section('title', 'Tambah Dokter - KlinikWeb')
@section('page_title', 'Tambah Dokter')

@section('content')
    <section class="panel">
        <form method="POST" action="{{ route('admin.doctors.store') }}">
            @include('admin.doctors._form')
        </form>
    </section>
@endsection
