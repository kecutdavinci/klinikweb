<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Appointment;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class AppointmentController extends Controller
{
    public function index(Request $request): View
    {
        $status = $request->query('status');

        return view('admin.appointments.index', [
            'appointments' => Appointment::with(['user', 'doctor', 'service', 'verifier'])
                ->when($status, fn ($query) => $query->where('status', $status))
                ->latest()
                ->paginate(10)
                ->withQueryString(),
            'status' => $status,
            'statuses' => Appointment::STATUSES,
        ]);
    }

    public function show(Appointment $appointment): View
    {
        return view('admin.appointments.show', [
            'appointment' => $appointment->load(['user', 'doctor', 'service', 'verifier']),
        ]);
    }

    public function verify(Request $request, Appointment $appointment): RedirectResponse
    {
        if (! in_array($appointment->status, ['pending', 'rejected'], true)) {
            return back()->with('error', 'Transaksi ini tidak bisa diverifikasi dari status saat ini.');
        }

        $data = $request->validate([
            'admin_note' => ['nullable', 'string'],
        ]);

        $appointment->update([
            'status' => 'verified',
            'admin_note' => $data['admin_note'] ?? 'Transaksi sudah diverifikasi admin.',
            'verified_by' => Auth::id(),
            'verified_at' => now(),
        ]);

        return redirect()->route('admin.appointments.show', $appointment)->with('status', 'Transaksi berhasil diverifikasi.');
    }

    public function reject(Request $request, Appointment $appointment): RedirectResponse
    {
        if (! in_array($appointment->status, ['pending', 'verified'], true)) {
            return back()->with('error', 'Transaksi ini tidak bisa ditolak dari status saat ini.');
        }

        $data = $request->validate([
            'admin_note' => ['required', 'string', 'max:1000'],
        ]);

        $appointment->update([
            'status' => 'rejected',
            'admin_note' => $data['admin_note'],
            'verified_by' => Auth::id(),
            'verified_at' => now(),
        ]);

        return redirect()->route('admin.appointments.show', $appointment)->with('status', 'Transaksi ditolak dengan catatan admin.');
    }

    public function complete(Request $request, Appointment $appointment): RedirectResponse
    {
        if ($appointment->status !== 'verified') {
            return back()->with('error', 'Hanya transaksi terverifikasi yang bisa diselesaikan.');
        }

        $data = $request->validate([
            'admin_note' => ['nullable', 'string'],
        ]);

        $appointment->update([
            'status' => 'completed',
            'admin_note' => $data['admin_note'] ?? $appointment->admin_note,
            'verified_by' => $appointment->verified_by ?: Auth::id(),
            'verified_at' => $appointment->verified_at ?: now(),
        ]);

        return redirect()->route('admin.appointments.show', $appointment)->with('status', 'Transaksi selesai.');
    }
}
