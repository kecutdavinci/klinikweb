@extends('layouts.app')

@section('title', 'Login - KlinikWeb')

@section('content')
    <section class="auth-card">
        <h1 class="auth-title">KlinikWeb</h1>
        <p class="muted">Masuk untuk mengelola layanan klinik.</p>

        <form class="form-grid" method="POST" action="{{ route('login.store') }}">
            @csrf
            <div class="field">
                <label for="email">Email</label>
                <input id="email" type="email" name="email" value="{{ old('email') }}" required autofocus>
            </div>

            <div class="field">
                <label for="password">Password</label>
                <input id="password" type="password" name="password" required>
            </div>

            <label class="checkbox">
                <input type="checkbox" name="remember" value="1">
                Ingat saya
            </label>

            <button class="btn" type="submit">Login</button>
        </form>

        <p class="auth-switch">
            Belum punya akun?
            <a href="{{ route('register') }}">Daftar user</a>
        </p>

        <div class="panel" style="margin-bottom:0;">
            <strong>Akun demo</strong>
            <div class="muted">Admin: admin@klinikweb.test / password</div>
            <div class="muted">User: user@klinikweb.test / password</div>
        </div>
    </section>
@endsection
