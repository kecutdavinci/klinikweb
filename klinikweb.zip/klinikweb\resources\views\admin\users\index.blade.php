@extends('layouts.app')

@section('title', 'Verifikasi User - KlinikWeb')
@section('page_title', 'Verifikasi User')

@section('content')
    <section class="panel">
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th>Daftar</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($users as $user)
                        <tr>
                            <td>{{ $user->name }}</td>
                            <td>{{ $user->email }}</td>
                            <td>
                                <span class="badge {{ $user->is_verified ? 'ok' : 'no' }}">
                                    {{ $user->is_verified ? 'Terverifikasi' : 'Belum' }}
                                </span>
                            </td>
                            <td>{{ $user->created_at->format('d M Y H:i') }}</td>
                            <td>
                                <div class="actions">
                                    @if($user->is_verified)
                                        <form method="POST" action="{{ route('admin.users.unverify', $user) }}">
                                            @csrf
                                            @method('PATCH')
                                            <button class="btn warning" type="submit">Batalkan</button>
                                        </form>
                                    @else
                                        <form method="POST" action="{{ route('admin.users.verify', $user) }}">
                                            @csrf
                                            @method('PATCH')
                                            <button class="btn success" type="submit">Verifikasi</button>
                                        </form>
                                    @endif

                                    <form method="POST" action="{{ route('admin.users.destroy', $user) }}" onsubmit="return confirm('Hapus user ini?')">
                                        @csrf
                                        @method('DELETE')
                                        <button class="btn danger" type="submit">Hapus</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="5">Belum ada user.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="pagination">{{ $users->links() }}</div>
    </section>
@endsection
