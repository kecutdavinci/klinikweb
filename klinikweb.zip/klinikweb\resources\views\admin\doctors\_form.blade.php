@csrf

<div class="form-grid">
    <div class="field">
        <label for="name">Nama Dokter</label>
        <input id="name" name="name" value="{{ old('name', $doctor->name) }}" required>
    </div>

    <div class="field">
        <label for="specialization">Spesialis</label>
        <input id="specialization" name="specialization" value="{{ old('specialization', $doctor->specialization) }}" required>
    </div>

    <div class="field">
        <label for="phone">No. Telepon</label>
        <input id="phone" name="phone" value="{{ old('phone', $doctor->phone) }}">
    </div>

    <div class="field">
        <label for="schedule">Jadwal Praktik</label>
        <input id="schedule" name="schedule" value="{{ old('schedule', $doctor->schedule) }}" placeholder="Senin-Jumat, 08.00-14.00" required>
    </div>

    <label class="checkbox">
        <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $doctor->exists ? $doctor->is_active : true))>
        Aktif
    </label>

    <div class="actions">
        <button class="btn" type="submit">Simpan</button>
        <a class="btn secondary" href="{{ route('admin.doctors.index') }}">Batal</a>
    </div>
</div>
