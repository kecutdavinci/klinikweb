<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Doctor;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class DoctorController extends Controller
{
    public function index(): View
    {
        return view('admin.doctors.index', [
            'doctors' => Doctor::latest()->paginate(10),
        ]);
    }

    public function create(): View
    {
        return view('admin.doctors.create', [
            'doctor' => new Doctor(),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        Doctor::create($this->validatedData($request));

        return redirect()->route('admin.doctors.index')->with('status', 'Data dokter berhasil ditambahkan.');
    }

    public function show(Doctor $doctor): RedirectResponse
    {
        return redirect()->route('admin.doctors.edit', $doctor);
    }

    public function edit(Doctor $doctor): View
    {
        return view('admin.doctors.edit', [
            'doctor' => $doctor,
        ]);
    }

    public function update(Request $request, Doctor $doctor): RedirectResponse
    {
        $doctor->update($this->validatedData($request));

        return redirect()->route('admin.doctors.index')->with('status', 'Data dokter berhasil diperbarui.');
    }

    public function destroy(Doctor $doctor): RedirectResponse
    {
        if ($doctor->appointments()->exists()) {
            return back()->with('error', 'Dokter tidak bisa dihapus karena sudah dipakai pada transaksi.');
        }

        $doctor->delete();

        return redirect()->route('admin.doctors.index')->with('status', 'Data dokter berhasil dihapus.');
    }

    private function validatedData(Request $request): array
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'specialization' => ['required', 'string', 'max:120'],
            'phone' => ['nullable', 'string', 'max:30'],
            'schedule' => ['required', 'string', 'max:150'],
        ]);

        $data['is_active'] = $request->boolean('is_active');

        return $data;
    }
}
