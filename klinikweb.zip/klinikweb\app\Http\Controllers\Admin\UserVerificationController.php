<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class UserVerificationController extends Controller
{
    public function index(): View
    {
        return view('admin.users.index', [
            'users' => User::where('role', 'user')->latest()->paginate(10),
        ]);
    }

    public function verify(User $user): RedirectResponse
    {
        $user->update([
            'is_verified' => true,
            'email_verified_at' => $user->email_verified_at ?: now(),
        ]);

        return back()->with('status', 'Akun user berhasil diverifikasi.');
    }

    public function unverify(User $user): RedirectResponse
    {
        $user->update(['is_verified' => false]);

        return back()->with('status', 'Verifikasi akun user dibatalkan.');
    }

    public function destroy(User $user): RedirectResponse
    {
        if ($user->role === 'admin') {
            return back()->with('error', 'Akun admin tidak bisa dihapus dari halaman ini.');
        }

        if ($user->appointments()->exists()) {
            return back()->with('error', 'User tidak bisa dihapus karena sudah memiliki transaksi.');
        }

        $user->delete();

        return back()->with('status', 'User berhasil dihapus.');
    }
}
