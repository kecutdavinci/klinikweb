<?php

use App\Http\Controllers\Admin\AppointmentController as AdminAppointmentController;
use App\Http\Controllers\Admin\DoctorController as AdminDoctorController;
use App\Http\Controllers\Admin\ServiceController as AdminServiceController;
use App\Http\Controllers\Admin\UserVerificationController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\User\AppointmentController as UserAppointmentController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return auth()->check()
        ? redirect()->route('dashboard')
        : redirect()->route('login');
});

Route::middleware('guest')->group(function (): void {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->name('login.store');
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register'])->name('register.store');
});

Route::middleware('auth')->group(function (): void {
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    Route::middleware('role:admin')->prefix('admin')->name('admin.')->group(function (): void {
        Route::get('/dashboard', [DashboardController::class, 'admin'])->name('dashboard');
        Route::resource('doctors', AdminDoctorController::class);
        Route::resource('services', AdminServiceController::class);

        Route::get('/users', [UserVerificationController::class, 'index'])->name('users.index');
        Route::patch('/users/{user}/verify', [UserVerificationController::class, 'verify'])->name('users.verify');
        Route::patch('/users/{user}/unverify', [UserVerificationController::class, 'unverify'])->name('users.unverify');
        Route::delete('/users/{user}', [UserVerificationController::class, 'destroy'])->name('users.destroy');

        Route::get('/appointments', [AdminAppointmentController::class, 'index'])->name('appointments.index');
        Route::get('/appointments/{appointment}', [AdminAppointmentController::class, 'show'])->name('appointments.show');
        Route::patch('/appointments/{appointment}/verify', [AdminAppointmentController::class, 'verify'])->name('appointments.verify');
        Route::patch('/appointments/{appointment}/reject', [AdminAppointmentController::class, 'reject'])->name('appointments.reject');
        Route::patch('/appointments/{appointment}/complete', [AdminAppointmentController::class, 'complete'])->name('appointments.complete');
    });

    Route::middleware('role:user')->group(function (): void {
        Route::get('/user/dashboard', [DashboardController::class, 'user'])->name('user.dashboard');
        Route::resource('appointments', UserAppointmentController::class);
        Route::patch('/appointments/{appointment}/cancel', [UserAppointmentController::class, 'cancel'])->name('appointments.cancel');
    });
});
