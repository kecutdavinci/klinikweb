@extends('layouts.app')

@section('title', 'Tambah Layanan - KlinikWeb')
@section('page_title', 'Tambah Layanan')

@section('content')
    <section class="panel">
        <form method="POST" action="{{ route('admin.services.store') }}">
            @include('admin.services._form')
        </form>
    </section>
@endsection
