<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use App\Models\Doctor;
use App\Models\Service;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function index(): RedirectResponse
    {
        return Auth::user()->isAdmin()
            ? redirect()->route('admin.dashboard')
            : redirect()->route('user.dashboard');
    }

    public function admin(): View
    {
        return view('dashboards.admin', [
            'totalUsers' => User::where('role', 'user')->count(),
            'pendingUsers' => User::where('role', 'user')->where('is_verified', false)->count(),
            'totalDoctors' => Doctor::count(),
            'totalServices' => Service::count(),
            'pendingAppointments' => Appointment::where('status', 'pending')->count(),
            'completedAppointments' => Appointment::where('status', 'completed')->count(),
            'latestAppointments' => Appointment::with(['user', 'doctor', 'service'])
                ->latest()
                ->take(6)
                ->get(),
        ]);
    }

    public function user(): View
    {
        $user = Auth::user();

        return view('dashboards.user', [
            'appointments' => $user->appointments()
                ->with(['doctor', 'service', 'verifier'])
                ->latest()
                ->take(5)
                ->get(),
            'totalAppointments' => $user->appointments()->count(),
            'pendingAppointments' => $user->appointments()->where('status', 'pending')->count(),
            'verifiedAppointments' => $user->appointments()->where('status', 'verified')->count(),
            'services' => Service::where('is_active', true)->orderBy('name')->take(4)->get(),
            'doctors' => Doctor::where('is_active', true)->orderBy('name')->take(4)->get(),
        ]);
    }
}
