# KlinikWeb

KlinikWeb adalah aplikasi Laravel untuk tugas Pemrograman Web 2. Aplikasi ini dibuat mirip konsep klinik: user membuat janji layanan, admin mengelola master data dan memverifikasi transaksi.

## Fitur

- Login dan register.
- Role minimal: admin dan user.
- Verifikasi akun user oleh admin.
- CRUD data dokter oleh admin.
- CRUD data layanan oleh admin.
- Transaksi janji layanan antara user dan admin.
- Verifikasi, penolakan, penyelesaian, pembatalan, dan catatan admin pada transaksi.

## Akun Demo

- Admin: `admin@klinikweb.test` / `password`
- User terverifikasi: `user@klinikweb.test` / `password`
- User belum verifikasi: `baru@klinikweb.test` / `password`

## Cara Install di Laragon

1. Extract folder `klinikweb` ke `C:\laragon\www\klinikweb`.
2. Buka Laragon, pastikan Apache/Nginx dan MySQL menyala.
3. Buka terminal Laragon, masuk ke folder project:

```bash
cd C:\laragon\www\klinikweb
```

4. Install dependency PHP:

```bash
composer install
```

5. Buat file environment:

```bash
copy .env.example .env
php artisan key:generate
```

6. Buat database MySQL bernama `klinikweb` lewat phpMyAdmin, HeidiSQL, atau menu Database Laragon.
7. Edit file `.env`, ubah bagian database menjadi:

```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=klinikweb
DB_USERNAME=root
DB_PASSWORD=
```

8. Jalankan migrasi dan data awal:

```bash
php artisan migrate:fresh --seed
```

9. Jalankan aplikasi:

```bash
php artisan serve --host=127.0.0.1 --port=8000
```

10. Buka browser:

```text
http://127.0.0.1:8000
```

## Alur Penggunaan

1. Login sebagai admin.
2. Buka menu `Verifikasi User`, lalu verifikasi user yang belum aktif.
3. Kelola `Data Dokter` dan `Data Layanan`.
4. Login sebagai user terverifikasi.
5. Buat janji layanan dari menu `Janji Layanan`.
6. Login kembali sebagai admin.
7. Buka menu `Transaksi`, lalu verifikasi, tolak, atau selesaikan transaksi.
8. User dapat melihat status transaksi dan catatan admin.

## Catatan

- Project ini memakai Laravel 13 dan membutuhkan PHP 8.3 atau lebih baru.
- Jika ingin memakai SQLite untuk testing cepat, biarkan `DB_CONNECTION=sqlite`, buat file `database/database.sqlite`, lalu jalankan `php artisan migrate:fresh --seed`.
