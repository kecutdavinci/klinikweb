@extends('layouts.app')

@section('title', 'Buat Janji - KlinikWeb')
@section('page_title', 'Buat Janji Layanan')

@section('content')
    <section class="panel">
        <form method="POST" action="{{ route('appointments.store') }}">
            @include('user.appointments._form')
        </form>
    </section>
@endsection
